const express = require('express');
const app = express();
const port = 3000;

app.get('/hello', (req, res) => {
  res.send('Hello Express JS');
});

app.get('/user', (req, res) => {
  const firstName = req.query.firstname || 'Pritesh';
  const lastName = req.query.lastname || 'Patel';
  const user = { firstname: firstName, lastname: lastName };
  res.json(user);
});

app.post('/user/:firstname/:lastname', (req, res) => {
  const firstName = req.params.firstname || 'Pritesh';
  const lastName = req.params.lastname || 'Patel';
  const user = { firstname: firstName, lastname: lastName };
  res.json(user);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
